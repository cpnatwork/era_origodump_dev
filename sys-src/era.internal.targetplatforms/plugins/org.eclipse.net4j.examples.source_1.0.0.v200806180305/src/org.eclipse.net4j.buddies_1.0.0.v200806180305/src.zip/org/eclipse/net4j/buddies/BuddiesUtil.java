/***************************************************************************
 * Copyright (c) 2004 - 2008 Eike Stepper, Germany.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors:
 *    Eike Stepper - initial API and implementation
 **************************************************************************/
package org.eclipse.net4j.buddies;

import org.eclipse.net4j.buddies.internal.common.protocol.ProtocolConstants;
import org.eclipse.net4j.buddies.spi.common.ClientFacilityFactory;
import org.eclipse.net4j.channel.IChannel;
import org.eclipse.net4j.connector.IConnector;
import org.eclipse.net4j.internal.buddies.protocol.OpenSessionRequest;
import org.eclipse.net4j.signal.SignalActor;
import org.eclipse.net4j.util.WrappedException;
import org.eclipse.net4j.util.container.IPluginContainer;

import java.util.Set;

/**
 * @author Eike Stepper
 */
public final class BuddiesUtil
{
  private BuddiesUtil()
  {
  }

  public static Set<String> getFacilityTypes()
  {
    return IPluginContainer.INSTANCE.getFactoryTypes(ClientFacilityFactory.PRODUCT_GROUP);
  }

  public static IBuddySession openSession(IConnector connector, String userID, String password, long timeout)
  {
    try
    {
      IChannel channel = connector.openChannel(ProtocolConstants.PROTOCOL_NAME, null);
      OpenSessionRequest request = new OpenSessionRequest(channel, userID, password, getFacilityTypes());
      return request.send(timeout);
    }
    catch (Exception ex)
    {
      throw WrappedException.wrap(ex);
    }
  }

  public static IBuddySession openSession(IConnector connector, String userID, String password)
  {
    return openSession(connector, userID, password, SignalActor.NO_TIMEOUT);
  }
}
