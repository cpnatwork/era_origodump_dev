/**
 *
 * Copyright (c) 2008 IBM Corporation and others.
 * All rights reserved.   This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Contributors: 
 *   IBM - Initial API and implementation
 *
 */
package org.eclipse.jet.internal.taglib.java;

import java.util.HashMap;
import java.util.Map;

import org.eclipse.jet.taglib.CustomTag;
import org.eclipse.jet.taglib.JET2TagException;
import org.eclipse.jet.taglib.TagInstanceFactory;

/**
 * Tag Factory for javaTags
 */
public class TagFactory implements TagInstanceFactory
{

  private final Map tagOrdinalByName;
  
  /**
   * 
   */
  public TagFactory()
  {
    tagOrdinalByName = new HashMap(7);

    tagOrdinalByName.put("class",new Integer(1)); //$NON-NLS-1$
    tagOrdinalByName.put("impliedImport",new Integer(2)); //$NON-NLS-1$
    tagOrdinalByName.put("import",new Integer(3)); //$NON-NLS-1$
    tagOrdinalByName.put("importsLocation",new Integer(4)); //$NON-NLS-1$
    tagOrdinalByName.put("merge",new Integer(5)); //$NON-NLS-1$
    tagOrdinalByName.put("package",new Integer(6)); //$NON-NLS-1$
    tagOrdinalByName.put("resource",new Integer(7)); //$NON-NLS-1$
  }

  public CustomTag createCustomTag(String name)
  {
    Integer ordinal = (Integer)tagOrdinalByName.get(name);
    
    switch(ordinal == null ? 0 : ordinal.intValue()) {
      case 1: // class
        return new org.eclipse.jet.internal.taglib.java.JavaClassTag();
      case 2: // impliedImport
        return new org.eclipse.jet.internal.taglib.java.ImpliedImportTag();
      case 3: // import
        return new org.eclipse.jet.internal.taglib.java.ImportTag();
      case 4: // importsLocation
        return new org.eclipse.jet.internal.taglib.java.ImportsLocationTag();
      case 5: // merge
        return new org.eclipse.jet.internal.taglib.java.MergeTag();
      case 6: // package
        return new org.eclipse.jet.internal.taglib.java.PackageTag();
      case 7: // resource
        return new org.eclipse.jet.internal.taglib.java.JavaResourceTag();
      default:
        throw new JET2TagException("Unknown Tag: " + name); //$NON-NLS-1$
    }
  }

}
