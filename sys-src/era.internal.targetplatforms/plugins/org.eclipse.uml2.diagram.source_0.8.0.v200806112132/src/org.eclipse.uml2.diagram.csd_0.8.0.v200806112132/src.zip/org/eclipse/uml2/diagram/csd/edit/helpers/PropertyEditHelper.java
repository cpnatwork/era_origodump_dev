package org.eclipse.uml2.diagram.csd.edit.helpers;

/**
 * @generated
 */
public class PropertyEditHelper extends UMLBaseEditHelper {
}
