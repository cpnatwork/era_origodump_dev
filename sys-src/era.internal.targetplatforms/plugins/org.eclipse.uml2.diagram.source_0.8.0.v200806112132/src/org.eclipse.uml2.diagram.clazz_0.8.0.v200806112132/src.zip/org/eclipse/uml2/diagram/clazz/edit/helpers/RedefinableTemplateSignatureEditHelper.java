package org.eclipse.uml2.diagram.clazz.edit.helpers;

/**
 * @generated
 */
public class RedefinableTemplateSignatureEditHelper extends UMLBaseEditHelper {
}