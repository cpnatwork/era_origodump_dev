package org.eclipse.uml2.diagram.clazz.edit.helpers;

/**
 * @generated
 */
public class PortEditHelper extends UMLBaseEditHelper {
}