package org.eclipse.uml2.diagram.activity.edit.helpers;

import org.eclipse.gmf.runtime.emf.type.core.edithelper.AbstractEditHelperAdvice;

/**
 * @generated
 */
public class DecisionNodeEditHelperAdvice extends AbstractEditHelperAdvice {
}
