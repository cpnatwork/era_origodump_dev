package org.eclipse.uml2.diagram.statemachine.edit.helpers;

/**
 * @generated
 */
public class BehaviorEditHelper extends UMLBaseEditHelper {
}
