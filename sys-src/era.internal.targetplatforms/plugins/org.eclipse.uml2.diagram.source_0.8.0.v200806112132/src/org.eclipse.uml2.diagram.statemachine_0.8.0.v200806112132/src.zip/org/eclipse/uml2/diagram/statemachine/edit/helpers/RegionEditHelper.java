package org.eclipse.uml2.diagram.statemachine.edit.helpers;

/**
 * @generated
 */
public class RegionEditHelper extends UMLBaseEditHelper {
}
