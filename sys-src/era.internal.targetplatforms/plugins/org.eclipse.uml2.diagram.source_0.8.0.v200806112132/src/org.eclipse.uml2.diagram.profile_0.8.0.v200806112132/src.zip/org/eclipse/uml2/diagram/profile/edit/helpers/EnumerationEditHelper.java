package org.eclipse.uml2.diagram.profile.edit.helpers;

/**
 * @generated
 */
public class EnumerationEditHelper extends UMLBaseEditHelper {
}