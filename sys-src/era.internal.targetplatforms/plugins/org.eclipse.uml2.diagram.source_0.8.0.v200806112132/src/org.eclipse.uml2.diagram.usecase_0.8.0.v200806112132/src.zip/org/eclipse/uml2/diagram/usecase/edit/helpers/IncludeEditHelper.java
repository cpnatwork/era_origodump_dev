package org.eclipse.uml2.diagram.usecase.edit.helpers;

/**
 * @generated
 */
public class IncludeEditHelper extends UMLBaseEditHelper {
}
