package org.eclipse.uml2.diagram.usecase.edit.helpers;

/**
 * @generated
 */
public class AssociationEditHelper extends UMLBaseEditHelper {
}
