package org.eclipse.uml2.diagram.usecase.edit.helpers;

/**
 * @generated
 */
public class ComponentEditHelper extends UMLBaseEditHelper {
}
