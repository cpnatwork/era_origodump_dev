package org.eclipse.uml2.diagram.common.preferences;

import org.eclipse.gmf.runtime.common.ui.preferences.AbstractPreferencePage;
import org.eclipse.swt.widgets.Composite;


public class MainPreferencePage extends AbstractPreferencePage {

	@Override
	protected void addFields(Composite parent) {
	}

	@Override
	protected void initHelp() {
	}

}
