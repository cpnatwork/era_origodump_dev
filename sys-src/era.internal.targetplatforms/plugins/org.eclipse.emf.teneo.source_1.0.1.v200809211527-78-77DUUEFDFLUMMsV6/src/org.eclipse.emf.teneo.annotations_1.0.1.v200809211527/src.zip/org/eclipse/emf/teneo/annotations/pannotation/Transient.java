/**
 * <copyright>
 * </copyright>
 *
 * $Id: Transient.java,v 1.5 2007/07/04 19:28:01 mtaal Exp $
 */
package org.eclipse.emf.teneo.annotations.pannotation;

/**
 * <!-- begin-user-doc --> A representation of the model object '<em><b>Transient</b></em>'. <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.emf.teneo.annotations.pannotation.PannotationPackage#getTransient()
 * @model annotation="teneo/internal/Target 0='EModelElement'"
 * @generated
 */
public interface Transient extends PAnnotation {

} // Transient
