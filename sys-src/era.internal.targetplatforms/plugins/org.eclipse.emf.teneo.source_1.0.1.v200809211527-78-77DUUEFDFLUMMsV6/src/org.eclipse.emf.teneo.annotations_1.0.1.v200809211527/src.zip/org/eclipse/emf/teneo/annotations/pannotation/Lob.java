/**
 * <copyright>
 * </copyright>
 *
 * $Id: Lob.java,v 1.5 2007/07/04 19:28:01 mtaal Exp $
 */
package org.eclipse.emf.teneo.annotations.pannotation;

/**
 * <!-- begin-user-doc --> A representation of the model object '<em><b>Lob</b></em>'. <!-- end-user-doc -->
 *
 *
 * @see org.eclipse.emf.teneo.annotations.pannotation.PannotationPackage#getLob()
 * @model annotation="teneo/internal/Target 0='EAttribute'"
 *        annotation="http://www.eclipse.org/emf/2002/Ecore constraints='AllowedType'"
 * @generated
 */
public interface Lob extends PAnnotation {

} // Lob
